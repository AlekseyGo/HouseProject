=begin
Copyright 2006-2011 TIG (c)

Permission to use, copy, modify, and distribute this software for 
any purpose and without fee is hereby granted, provided the above
copyright notice appear in all copies.

THIS SOFTWARE IS PROVIDED "AS IS" AND WITHOUT ANY EXPRESS OR
IMPLIED WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.

Name: VolumeCalculator.rb

Description: A tool to calculate the volume of a selected Group/Instance

Context Menu: Volume...

Menu Item: See menu-section at end on how to include: Plugins -> Volume

Usage: First select a Group or Component that has faces that form a 
volume, then use the right-click Context-Menu and choose 'Volume...'.
If there is the Plugins Menu Item 'Volume' you can also pick that.
(see the end menu section on how to activate that option...)

A dialog asks for the volume units and the accuracy required.
The units can be cu.m, cc, cu.yds, cu.ft, cu.ins, litres, cl, ml, 
gallons(UK), gallons(USA), quarts(USA), pints(UK) and pints(USA).
Volumes are given to varying d.p's depending on the units chosen. 

IF Sketchup is <v8 you get extra options,,,
The accuracy can be 0.5, 1, 2, 5 or 10% - the more accurate you 
make it the longer it takes to process and the more complex the new 
volume-group will become.Small simple forms will report accurately 
even with the 10% sampling...

IF Sketchup is <v8 you get a group made with faces. 
The text-tag is added just above the the apex of the selection's 
bounding-box.
It shows the volume in the required units using the current 
text/font settings.

A possible new layer can be used.It is 
named VOLS-nnnnnnnn (where nnnnnnnn is based on the date/time). 
Alternatively you can choose to use any existing layer OR make 
your own 'on the fly'.

IF Sketchup is <v8 it then calculates a series of thin horizontal 
slices through the selection's faces to use to calculate the volume
enclosed. If Sketchup >=v8 then this is skipped.

There are now also new Layer, Hide/Show-Edges and Colour Options 
in v1.7, see below...***

IF Sketchup is <v8...
Before ending it checks if 'Xray Mode' was already switched 'on' at 
the start and if so there is no action and it exits.Otherwise the 
original selection is 'Hidden' so you can clearly see the volume-group.
You are then asked in a dialog if you want to leave it 'Hidden'.
If 'Yes' then it exits leaving it 'Hidden'.If 'No' the original 
selection is 'Unhidden' and 'Xray Mode' is then switched 'on' so you 
can see the volume-group inside of the original selection and a dialog 
asks if you want to leave 'Xray Mode' switched 'on'.  If you answer 
'No' the normal view is restored and it exits.  If you answer 'Yes' 
it exits leaving 'Xray Mode' switched 'on'.
If you don't want the slice to be visible you can edit the 
volume's group and either delete all of its geometry, leaving 
the text-tag in place, or just select all geometry and hide it.

'Volume' can't be expected to be 100% foolproof !It treats an open 
topped object as if it were filled with water, taking volumes from the 
outer 'skin' inwards to work out which are the solid and which are the 
hollow volumes.With a little ingenuity you will be able to contrive
a form with complex linked holes punched in, or a vertical array of 
thin volumes spaced apart so as to miss the sampling slices - which 
because it uses a series of horizontal slices, can produce unexpected 
results. Keep volumes simple and build them up in bits for safety...

***New Options(>=v1.7) let you choose any layer OR make a new one,
hide/show volume's edges and give faces any standard colour -
pick popout' type first letter of colour to jump down list -
e.g. W for White takes you to Wheat...: 
use up/down arrow keys to move through list...
or pick any model material listed...
If Sketchup >=v8 the text-tag is colored - so avoid colours matching
the background!

If a volume-group OR text-tag is selected then there's a 
right-click context-menu item to export ALL volume data into a 
CSV file...

Donations:
PayPal.com - info @ revitrev.org

Version:
2.0 20111004 New version with fast v8 calculation.
=end						
#-----------------------------------------------------------------------------
require 'sketchup.rb'
###
class VolumeIntegration
###---------------------------------------
def VolumeIntegration::calculate
### version error
if Sketchup.version.split(".")[0].to_i<5
     UI.messagebox("Sorry.  This is Version 5+ program only !")
     return nil
end#if
###
model = Sketchup.active_model
entities = model.entities
model.start_operation("Volume Integration")
ss = model.selection
view = model.active_view
  if ss.empty?
     UI.messagebox("NO Selection !")
     return nil
  end#if
  if ss[1]
     UI.messagebox("Selection MUST be ONE Group or Component !")
     return nil
  end#if
  if ss[0].class != Sketchup::Group and ss[0].class != Sketchup::ComponentInstance
     UI.messagebox("Selection is NOT a Group or Component !")
	 return nil
  end#if
###
selected = ss[0]
###
### Check for manifoldness
if Sketchup.version.split(".")[0].to_i>=8
  if not selected.manifold?
    UI.messagebox("The Selection is NOT Manifold and\ntherefore it has no meaningful Volume !")
   return nil
  end
end
###
# -------------- set up @units and @percent in def dialog for later...
# -------------- make cutting disc face at xy bounds
###
###
bb = selected.bounds
xmin = bb.min.x
ymin = bb.min.y
xmax = bb.max.x
ymax = bb.max.y
zmin = bb.min.z
zmax = bb.max.z
###
if xmin == xmax or ymin == ymax or zmin == zmax
   UI.messagebox("The Selection has no Volume !")
   return nil
end#if
###
# ----------- dialog ----------------
### show VCB and status info
  Sketchup::set_status_text(("VOLUME PARAMETERS..." ), SB_PROMPT)
  Sketchup::set_status_text(" ", SB_VCB_LABEL)
  Sketchup::set_status_text(" ", SB_VCB_VALUE)
  return nil if not VolumeIntegration.dialog ### do dialog...
###
########################################
if Sketchup.version.split(".")[0].to_i<8
########################################
#### ------- slice & z inc ------------------------------
slice = ((zmax-zmin)*@percent)### THE basic slice
increment_z = (zmax-zmin)/(((zmax-zmin)/slice).ceil)
###
apex = Geom.linear_combination(0.5,[xmin,ymin,zmax+2],0.5,[xmax,ymax,zmax+2])
### +2 puts it above top ( for text loc'n )
pnt1 = [xmin,ymin,zmin] ### v1.1
pnt2 = [xmax,ymax,zmin] ### v1.1
ctr = Geom.linear_combination(0.5,pnt1,0.5,pnt2)
rad = (pnt1.distance pnt2)### make a LOT bigger than bb ###v1.3
###
disc = entities.add_group
discentities = disc.entities
disccircle = VolumeIntegration.circle(ctr,[0,0,-1],rad,24)
discentities.add_face disccircle
###
#--------------------------- reset Z max and min's
###zmax = zmax-(increment_z/2)### v1.6 NOT required ###
zmin = zmin+(increment_z/2)
###
# ------------------------ do each of slice
vol=entities.add_group
volentities=vol.entities
###vol.name="Volume-"+@sfix
vol.name="Volume"### v1.8
###
### intersect disc and selected
###
### The intersect_with method is used to intersect entities, a component instance, or group
### with an entities object.
###
### entities.intersect_with recurse, transformation1, entities1, transformation2, hidden, entities2
###
### recurse - true if you want this entities object to be recursed 
###   (intersection lines will be put inside of groups and components within this entities object)
### transformation1 - the transformation for this entities object
### entities1 - the entities (group etc) where you want the intersection lines to appear
### transformation2 - the transformation for entities1
### hidden - true if you want hidden geometry in this entities object to be used in the intersection
###   (it's false in section cuts)
### entities2 - an entities object (or an array of entities ?)
###
### loop through all possible slices - bottom up
n = ((zmax-zmin)/slice).ceil
c = 0
z = increment_z/2 ### move to start v1.6 fix ###
while z < zmax-zmin+increment_z ### v1.6 fix ###
### show VCB and status info
  Sketchup::set_status_text(("MAKING VOLUME SLICE #{c} of #{n.to_i}" ), SB_PROMPT)
  Sketchup::set_status_text(" ", SB_VCB_LABEL)
  Sketchup::set_status_text(" ", SB_VCB_VALUE)
### do cut
  disc.move! Geom::Transformation.new([0,0,z]) ### first placing near bottom v1.6
  discentities.intersect_with true, disc.transformation, vol, vol.transformation, true, selected
  z = z+increment_z
  c = c+1
end#while
### delete disc
disc.erase!
### face the slices
for e in volentities
### show VCB and status info
  Sketchup::set_status_text(("MAKING VOLUME SLICES..." ), SB_PROMPT)
  Sketchup::set_status_text(" ", SB_VCB_LABEL)
  Sketchup::set_status_text(" ", SB_VCB_VALUE)
  e.find_faces if e.class==Sketchup::Edge
end#for e
###
faces = []
for f in volentities
   if f.class==Sketchup::Face
      faces = faces.push(f)
   end
end#for f
faces=faces.uniq
###
for face in faces
   face.reverse! if face.normal==[0,0,-1] ### now all face up
end#for face
### now work out which is which...
keptfaces = []
(faces.length-1).times do |this|
   for face in faces
    if face.valid?
      for edgeuse in face.outer_loop.edgeuses
         if not edgeuse.partners[0] ### outermost face
            keptfaces = keptfaces.push(face)
            faces = faces - [face]
            loops = face.loops
            for loop in loops
               for fac in faces
                  if fac.valid? and (fac.outer_loop.edges - loop.edges) == []
                     faces = faces - [fac]
                     fac.erase!### fac abutts kept face so it must be erased...
                  end #if fac
               end #for fac
            end #for loop
         end #if outermost
      end #for edgeuse
    end #if valid
   end #for face
end#times
###
layerVolume=@layer
if layerVolume
  layerVolume=model.layers.add(layerVolume)
  layerVolume.page_behavior=(LAYER_IS_HIDDEN_ON_NEW_PAGES | LAYER_HIDDEN_BY_DEFAULT) 
  layerVolume.visible=true
end#if
vol.layer=layerVolume
### -------------- now find area of all edges etc
colour=@colour
colour=nil if colour=="<Default>"
area = 0
for f in volentities
### show VCB and status info
  Sketchup::set_status_text(("CALCULATING VOLUME..." ), SB_PROMPT)
  Sketchup::set_status_text(" ", SB_VCB_LABEL)
  Sketchup::set_status_text(" ", SB_VCB_VALUE)
  f.material=colour if f.class==Sketchup::Face
  area=(area+f.area) if f.class==Sketchup::Face
  ###f.erase! if f.class == "Edge" and not f.faces[0]
  f.hidden= true if (f.valid? && f.class==Sketchup::Edge) && @hidden=="Yes"
end#for f
###
if area==0
   UI.messagebox("There is NO Volume !")
   vol.erase! if vol.valid?
   return nil
end#if
# --------------- get volume ----
###
volume=(area*increment_z)### in cubic inches
####
else ### it's v8
####
volume=selected.volume
volentities=selected.parent.entities
apex=selected.bounds.max
####
end#if <v8
###
if volume==0
   UI.messagebox("There is NO Volume !")
   vol.erase! if vol and vol.valid?
   return nil
end#if
if volume<0
   UI.messagebox("The Selected Object is not Manifold!\nThe Volume cannot be Calculated!")
   return nil
end#if
volume=volume.abs
####
### convert it to required units...
###["cu.m", "cc", "cu.yds", "cu.ft", "cu.ins", "litres", "cl", "ml", "gallons(UK)", "gallons(USA)", "quarts(USA)", "pints(UK)", "pints(USA)"]
volumetxt = volume.to_s
volumetxt = ((volume* 0.000016387064 *1000).round.to_f/1000).to_s if @units == "cu.m"
volumetxt = ((volume* 16.387064).round.to_i).to_s if @units == "cc"
volumetxt = ((volume* 0.000021433471 *1000).round.to_f/1000).to_s if @units == "cu.yds"
volumetxt = ((volume* 0.000578703704 *100).round.to_f/100).to_s if @units == "cu.ft"
volumetxt = ((volume *10).round.to_f/10).to_s if @units == "cu.ins"
volumetxt = ((volume* 0.016387064 *1000).round.to_f/1000).to_s if @units == "litres"
volumetxt = ((volume* 1.6387064 *10).round.to_f/10).to_s if @units == "cl"
volumetxt = ((volume* 16.387064).round.to_i).to_s if @units == "ml"
volumetxt = ((volume* 0.003604750773 *100).round.to_f/100).to_s if @units == "gallons(UK)"
volumetxt = ((volume* 0.004329125301 *100).round.to_f/100).to_s if @units == "gallons(USA)"
volumetxt = ((volume* 0.017316501203 *10).round.to_f/10).to_s if @units == "quarts(USA)"
volumetxt = ((volume* 0.028838006186 *10).round.to_f/10).to_s if @units == "pints(UK)"
volumetxt = ((volume* 0.034633002405 *10).round.to_f/10).to_s if @units == "pints(USA)"
########################################
if Sketchup.version.split(".")[0].to_i<8
########################################
  # add text
  t=volentities.add_text((volumetxt+" "+@units),apex,[1,2,3])
  t.layer=layerVolume ### NO units
  vol.name=volumetxt ### v1.8 #############################
  vol.set_attribute("Volume","Tag",true)### v1.8
else
  # add text
  t=volentities.add_text((volumetxt+" "+@units),apex,[3,4,5])
  t.layer=layerVolume ### NO units
  colour=@colour
  colour=nil if colour=="<Default>"
  t.material=colour
  t.set_attribute("Volume","Tag",true)
end
########################################
### show VCB and status info
  Sketchup::set_status_text(("" ), SB_PROMPT)
  Sketchup::set_status_text("", SB_VCB_LABEL)
  Sketchup::set_status_text("", SB_VCB_VALUE)
### unselected...
model.selection.clear
###
### hide selected
########################################
if Sketchup.version.split(".")[0].to_i<8
########################################
xray = 0
if not model.rendering_options["ModelTransparency"] ### NOT xray mode
   selected.hidden= true
   if UI.messagebox("Do you want to leave the Original Selection 'Hidden' for now ?  ",MB_YESNO,"Volume Hidden ?") == 7 ### 6=YES 7=NO
      xray = 1
      selected.hidden= false
   end#if
end#if
### xray ?
xrayq= 0
if not model.rendering_options["ModelTransparency"]
   xrayq = 1
   model.rendering_options["ModelTransparency"]=true if xray == 1
end#if
###
### ---- undo xray IF was not on already
if xray == 1 and xrayq == 1
  model.rendering_options["ModelTransparency"]=false if UI.messagebox("Do you want to leave 'Xray Mode' on for now ?  ",MB_YESNO,"Volume Xray ?")==7 ###7=NO
end#if
###
else
  ### it's v8!
end
### update view
view.invalidate
# ---------------------- Close/commit group
model.commit_operation
#-----------------------
end#def
###################################################---------------------
def VolumeIntegration::dialog
### get units and accuracy etc
   units = ["cu.m", "cc", "cu.yds", "cu.ft", "cu.ins", "litres", "cl", "ml", "gallons(UK)", "gallons(USA)", "quarts(USA)", "pints(UK)", "pints(USA)"].join('|')
   percents = ["0.5 %", "1 %", "2 %", "5 %", "10 %"].join('|')
   mlayers=Sketchup.active_model.layers
   layers=[]
   mlayers.each{|e|layers.push e.name}
   dlayer=layers[0]
   layers=layers-[dlayer]
   layers.sort!
   #----------- sort possible special Layer
   @sfix=Time::now.to_i.to_s[3..-1]
   layerVolume=("VOLS-"+@sfix)
   @makelayer="<Make New Layer>"
   layers=[layerVolume]+[@makelayer]+[dlayer]+layers
   layers.uniq!
   layers=layers.join('|')
   hidden="Yes|No"
   mcolours=Sketchup.active_model.materials
   colours=[]
   mcolours.each{|e|colours.push e.name}
   colours.sort!
   colours=colours+["<Default>"]+(Sketchup::Color.names.sort!)
   colours.uniq!
   colours=colours.join('|')
   title = "Volume Parameters"
   @units = "cu.m" if not @units
   @layer=layerVolume if not @layer ### v1.8 ##############
   @hidden="Yes" if not @hidden
   @colour="<Default>" if not @colour
   if Sketchup.version.split(".")[0].to_i<8
     @dpercent = "5 %" if not @dpercent
     prompts = ["Units: ","Accuracy: ","Layer: ","Hide Edges ? : ","Colour: "]
     values = [@units,@dpercent,@layer,@hidden,@colour]
     popups = [units,percents,layers,hidden,colours]
   else ###v8
     prompts = ["Units: ","Layer: ","Hide Edges ? : ","Colour: "]
     values = [@units,@layer,@hidden,@colour]
     popups = [units,layers,hidden,colours]
   end
   results = inputbox(prompts,values,popups,title)
   return nil if not results
### do processing of results
if Sketchup.version.split(".")[0].to_i<8
  @units,@dpercent,@layer,@hidden,@colour=results
  @percent = 0.005 if @dpercent == "0.5 %"
  @percent = 0.01 if @dpercent == "1 %"
  @percent = 0.02 if @dpercent == "2 %"
  @percent = 0.05 if @dpercent == "5 %"
  @percent = 0.1 if @dpercent == "10 %"
else ###v8
  @units,@layer,@hidden,@colour=results
end
### make layer dialog
if @layer==@makelayer
   results2=inputbox(["New Volume's Layer Name: "],["VOLS-????"],"New Layer Name")
   if results2
      @layer=results2[0]
   else
      @layer=nil
   end#if
end#if
###
true
###
end #def dialog
##################
# --- Function for generating points on a circle
def VolumeIntegration::circle(center,normal,radius,numseg)
    # Get the x and y axes
    axes = Geom::Vector3d.new(normal).axes
    center = Geom::Point3d.new(center)
    xaxis = axes[0]
    yaxis = axes[1]
    xaxis.length = radius
    yaxis.length = radius
    # compute the points
    da = (Math::PI * 2) / numseg
    pts = []
    for i in 0...numseg do
        angle = i * da
        cosa = Math.cos(angle)
        sina = Math.sin(angle)
        vec = Geom::Vector3d.linear_combination(cosa,xaxis,sina,yaxis)
        pts.push(center + vec)
    end
    # close the circle
    pts.push(pts[0].clone)
    pts
end#def
###########################
def VolumeIntegration::list ### v1.8
  model=Sketchup.active_model
  ### check model is saved...
  mname=model.title
  if mname==""
    UI.messagebox("This 'Untitled' new Model must be Saved\nbefore making a Volumes CSV List !\nExiting... ")
    return nil
  end
  mpath=(model.path.split("\\")[0..-2]).join("/")###strip off file name
  entities=model.active_entities
  vols=[]
  entities.each{|e|
    if e.class==Sketchup::Group and e.get_attribute("Volume","Tag",false)
	  vols.push(e.name)
	end#if
  }
  model.start_operation("Volume >>> CSV")
  ###
  Sketchup::set_status_text(("Volume >>> CSV ..." ), SB_PROMPT)
   Sketchup::set_status_text(" ", SB_VCB_LABEL)
   Sketchup::set_status_text(" ", SB_VCB_VALUE)
  vols.sort!
  vcsv=mpath+"/"+mname+"_Volumes.csv"
  begin
    file=File.new(vcsv,"w")
  rescue### trap if open
    UI.messagebox("Volume >>> CSV:\n\n  "+vcsv+"\n\nCannot be written - it's probably already open.\nClose it and try making the List again...\n\nExiting...")
	return nil
  end
  vols.each{|e|
    file.puts(e+"\n")
  }
  file.close
  UI.messagebox("Volume >>> CSV:\n\n  "+vcsv+"\n\nCompleted.")
  ###
  model.commit_operation
end#def
###########################
#-----------------------
end#class
#-----------------------
#--------- menu -----------------------------
if( not file_loaded?("VolumeCalculator.rb") )
   ###add_separator_to_menu("Plugins")
   ###UI.menu("Plugins").add_item("VolumeIntegration"){VolumeIntegration.calculate()}
   ###UI.menu("Plugins").add_item("VolumeIntegration >>> CSV"){VolumeIntegration.list()}
### remove ### in front of above 2 lines if to display in Plugins...
   UI.add_context_menu_handler do | menu |
      if Sketchup.active_model.selection[0] and (Sketchup.active_model.selection[0].class==Sketchup::Group or Sketchup.active_model.selection[0].class==Sketchup::ComponentInstance)
         menu.add_separator
         if Sketchup.version.split(".")[0].to_i<8
           txt="Volume [Integration]"
         else
           txt="Volume [v8]"
         end
         menu.add_item(txt){VolumeIntegration.calculate()}
      end #if ok
      if Sketchup.active_model.selection[0] and Sketchup.active_model.selection[0].get_attribute("Volume","Tag",false)
         menu.add_item(txt+" >>> CSV"){Volume.list()}
      end #if ok
   end #do menu
end#if
file_loaded("VolumeCalculator.rb")
#---------------------------------
